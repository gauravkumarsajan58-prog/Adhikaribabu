 "use client";
import { useMemo, useState } from "react";

const categories = [
  ["💼","Latest Jobs","124"],
  ["📝","Admit Card","38"],
  ["🏆","Results","52"],
  ["📢","Recruitment","67"],
  ["📚","Study Material","94"],
  ["📄","Free PDFs","81"]
];

const posts = [
  {tag:"Latest Job", title:"Government Recruitment 2026 — नई भर्ती की पूरी जानकारी", meta:"15 Aug 2026 • 12,540 views"},
  {tag:"Admit Card", title:"Admit Card 2026: डाउनलोड लिंक और परीक्षा की जानकारी", meta:"15 Aug 2026 • 8,420 views"},
  {tag:"Result", title:"Latest Result 2026 जारी — ऐसे करें अपना रिजल्ट चेक", meta:"14 Aug 2026 • 6,210 views"},
  {tag:"Study Material", title:"Physics Handwritten Notes — Free PDF", meta:"14 Aug 2026 • 11,030 views"},
  {tag:"Recruitment", title:"Railway / PSU Recruitment 2026 — Eligibility & Dates", meta:"13 Aug 2026 • 9,870 views"},
  {tag:"Free PDF", title:"General Knowledge Notes PDF — Competitive Exams", meta:"13 Aug 2026 • 7,450 views"}
];

export default function Home(){
 const [query,setQuery]=useState("");
 const filtered=useMemo(()=>posts.filter(p=>p.title.toLowerCase().includes(query.toLowerCase())||p.tag.toLowerCase().includes(query.toLowerCase())),[query]);
 return <main>
  <header className="bg-white border-b sticky top-0 z-20">
   <div className="container flex items-center justify-between gap-4 py-4">
    <a href="#" className="flex items-center gap-2">
      <div className="w-10 h-10 rounded-xl bg-blue-700 text-white grid place-items-center font-black text-lg">A</div>
      <div><div className="font-black text-xl leading-5">Adhikari<span className="text-blue-700">Babu</span></div><div className="text-[11px] text-gray-500">Jobs • Education • Updates</div></div>
    </a>
    <nav className="hidden md:flex gap-6 text-sm font-semibold text-gray-700">
      <a href="#jobs">Latest Jobs</a><a href="#results">Results</a><a href="#study">Study Material</a><a href="#about">About</a>
    </nav>
    <button className="rounded-xl bg-blue-700 text-white px-4 py-2.5 font-bold text-sm">Login</button>
   </div>
  </header>

  <section className="bg-gradient-to-br from-blue-800 via-blue-700 to-indigo-700 text-white">
   <div className="container py-12 md:py-16 grid md:grid-cols-[1.2fr_.8fr] gap-10 items-center">
    <div>
      <span className="inline-flex bg-white/15 border border-white/20 px-3 py-1.5 rounded-full text-sm font-bold">🇮🇳 आपका अपना Education & Jobs Platform</span>
      <h1 className="text-4xl md:text-6xl font-black mt-5 leading-tight">नौकरी, रिजल्ट और पढ़ाई की <span className="text-yellow-300">सही जानकारी</span> एक जगह।</h1>
      <p className="mt-4 text-blue-100 text-base md:text-lg max-w-2xl">Latest Government Jobs, Admit Card, Results, Recruitment Updates और Free Study Material — आसान भाषा में।</p>
      <div className="mt-7 flex flex-col sm:flex-row gap-3">
        <a href="#jobs" className="bg-white text-blue-800 px-5 py-3 rounded-xl font-extrabold text-center">Latest Jobs देखें →</a>
        <a href="#study" className="border border-white/30 bg-white/10 px-5 py-3 rounded-xl font-extrabold text-center">Free Notes 📚</a>
      </div>
    </div>
    <div className="card p-5 bg-white/10 border-white/20 text-white">
      <div className="font-bold mb-3">🔎 Website पर खोजें</div>
      <div className="flex gap-2">
       <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Job, Result, Admit Card..." className="min-w-0 flex-1 rounded-xl px-4 py-3 text-gray-800 outline-none"/>
       <button className="rounded-xl bg-yellow-400 text-gray-900 px-4 font-black">Search</button>
      </div>
      <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
       <div className="bg-white/10 rounded-xl p-3"><b>500+</b><br/><span className="text-blue-100">Updates</span></div>
       <div className="bg-white/10 rounded-xl p-3"><b>100+</b><br/><span className="text-blue-100">PDF Notes</span></div>
      </div>
    </div>
   </div>
  </section>

  <section className="container -mt-7 relative z-10">
   <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
    {categories.map(([icon,name,count])=><a key={name} href={"#"+name.toLowerCase().replace(" ","-")} className="card p-4 hover:-translate-y-1 transition">
      <div className="text-2xl">{icon}</div><div className="font-extrabold mt-2">{name}</div><div className="text-xs text-gray-500 mt-1">{count} updates</div>
    </a>)}
   </div>
  </section>

  <section id="jobs" className="container py-12">
   <div className="flex items-end justify-between gap-4 mb-5"><div><div className="text-blue-700 font-bold text-sm">LATEST UPDATES</div><h2 className="text-2xl md:text-3xl font-black">ताज़ा जानकारी</h2></div><button className="text-blue-700 font-bold text-sm">View All →</button></div>
   <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
    {filtered.map(p=><article className="card p-5 hover:shadow-lg transition" key={p.title}><span className="badge">{p.tag}</span><h3 className="font-extrabold text-lg mt-3 leading-snug">{p.title}</h3><p className="text-sm text-gray-500 mt-3">{p.meta}</p><button className="mt-4 text-blue-700 font-bold text-sm">Read More →</button></article>)}
   </div>
   {!filtered.length && <div className="card p-8 text-center text-gray-500">कोई result नहीं मिला।</div>}
  </section>

  <section id="study" className="bg-white border-y">
   <div className="container py-12">
    <div className="grid md:grid-cols-2 gap-8 items-center">
      <div><span className="badge">FREE STUDY MATERIAL</span><h2 className="text-3xl font-black mt-3">पढ़ाई के लिए Useful Notes & PDFs</h2><p className="text-gray-600 mt-3 leading-7">Competitive exams के लिए handwritten notes, GK, Maths, Physics और अन्य study material को एक जगह organize किया जाएगा।</p><button className="mt-5 bg-blue-700 text-white rounded-xl px-5 py-3 font-bold">Study Material देखें →</button></div>
      <div className="grid grid-cols-2 gap-3">{["📘 Physics","📐 Maths","🌍 GK / GS","💻 Computer"].map(x=><div key={x} className="card p-5 font-extrabold">{x}<div className="text-xs text-gray-500 mt-2">Free PDFs</div></div>)}</div>
    </div>
   </div>
  </section>

  <section id="results" className="container py-12">
    <div className="card overflow-hidden">
      <div className="p-6 bg-gray-50 border-b"><h2 className="text-2xl font-black">🔥 Trending Updates</h2><p className="text-gray-500 mt-1">सबसे ज्यादा देखी जा रही जानकारी</p></div>
      <div className="divide-y">{["IOCL Apprentice 2026 — Shortlist & DV Update","Latest Government Jobs August 2026","Railway Recruitment 2026 — Eligibility","Free Physics Handwritten Notes PDF","Latest Exam Results 2026"].map((x,i)=><div className="p-5 flex items-center justify-between gap-4" key={x}><div><span className="text-blue-700 font-black mr-3">0{i+1}</span><b>{x}</b><div className="text-xs text-gray-500 mt-1">Updated recently</div></div><span>→</span></div>)}</div>
    </div>
  </section>

  <section id="about" className="bg-slate-950 text-white">
   <div className="container py-12 grid md:grid-cols-3 gap-8">
    <div><div className="font-black text-2xl">Adhikari<span className="text-blue-400">Babu</span></div><p className="text-slate-400 mt-3 text-sm leading-6">Education, Jobs और useful information को आसान भाषा में उपलब्ध कराने का platform.</p></div>
    <div><h3 className="font-bold">Quick Links</h3><div className="text-slate-400 text-sm space-y-2 mt-3"><div>Latest Jobs</div><div>Results</div><div>Admit Card</div><div>Study Material</div></div></div>
    <div><h3 className="font-bold">Join Community</h3><p className="text-slate-400 text-sm mt-3">Latest updates के लिए हमारे social channels से जुड़ें।</p><button className="mt-4 bg-blue-600 px-4 py-2.5 rounded-xl font-bold">Join Telegram →</button></div>
   </div>
   <div className="border-t border-white/10"><div className="container py-5 text-xs text-slate-500">© 2026 AdhikariBabu. All rights reserved.</div></div>
  </section>
 </main>
}