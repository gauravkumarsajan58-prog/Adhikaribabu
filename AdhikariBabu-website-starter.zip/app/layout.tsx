import "./globals.css";
export const metadata = {
  title: "AdhikariBabu — Jobs, Results, Admit Card & Study Material",
  description: "Latest government jobs, admit cards, results, study material and useful updates."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="hi"><body>{children}</body></html>;
}