import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AdhikariBabu — Jobs, Results, Admit Card & Study Material",
  description:
    "AdhikariBabu: jobs, government results, admit cards, study material and exam updates.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="hi">
      <body>{children}</body>
    </html>
  );
}
