import PremiumDemo from "./PremiumDemo";

export default function PremiumPage() {
  return <PremiumDemo />;
}
