 "use client";

import { useState } from "react";

const premiumItems = [
  "Premium Study Notes & PDFs",
  "Exclusive Classes",
  "Premium Exam Material",
  "Important Questions & Revision Sets",
];

export default function PremiumDemo() {
  const [unlocked, setUnlocked] = useState(false);

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <header className="border-b border-white/10 bg-slate-950/95">
        <div className="container flex h-16 items-center justify-between">
          <a href="/" className="text-xl font-extrabold">
            Adhikari<span className="text-blue-400">Babu</span>
          </a>
          <a href="/" className="text-sm font-bold text-slate-300 hover:text-white">
            ← Home
          </a>
        </div>
      </header>

      <section className="container py-12 md:py-16">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex rounded-full bg-amber-400/10 px-4 py-2 text-sm font-black text-amber-300">
            ⭐ PREMIUM — DEMO MODE
          </span>

          <h1 className="mt-5 text-4xl font-black tracking-tight md:text-6xl">
            Premium Content
          </h1>

          <p className="mx-auto mt-4 max-w-2xl leading-7 text-slate-300">
            यह अभी केवल testing/demo के लिए है। Payment या real account system
            अभी connected नहीं है।
          </p>

          <div className="mx-auto mt-8 max-w-md rounded-3xl border border-white/10 bg-white/5 p-7">
            <p className="text-sm font-bold text-slate-400">LIFETIME ACCESS</p>
            <div className="mt-2 text-5xl font-black">₹99</div>
            <p className="mt-2 text-sm text-slate-400">One-time membership</p>

            {!unlocked ? (
              <button
                onClick={() => setUnlocked(true)}
                className="mt-7 w-full rounded-2xl bg-amber-400 px-5 py-4 font-black text-slate-950 hover:bg-amber-300"
              >
                🧪 Test Premium Access
              </button>
            ) : (
              <div className="mt-7 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-4 font-bold text-emerald-300">
                ✅ Premium Demo Unlocked
              </div>
            )}
          </div>
        </div>

        <div className="mx-auto mt-12 grid max-w-5xl gap-4 sm:grid-cols-2">
          {premiumItems.map((item, index) => (
            <div
              key={item}
              className="rounded-2xl border border-white/10 bg-white/5 p-5"
            >
              <div className="flex items-center gap-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-500/15 font-black text-blue-300">
                  {index + 1}
                </span>
                <div>
                  <h2 className="font-extrabold">{item}</h2>
                  <p className="mt-1 text-sm text-slate-400">
                    {unlocked ? "🔓 Demo access available" : "🔒 Premium content locked"}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mx-auto mt-10 max-w-3xl rounded-2xl border border-amber-400/20 bg-amber-400/5 p-5 text-center text-sm leading-6 text-slate-300">
          <strong className="text-amber-300">Testing note:</strong> इस button से
          कोई payment नहीं होता और कोई real membership नहीं बनती। बाद में
          secure login + payment gateway + server-side access control जोड़कर
          इसे real Premium system बनाया जा सकता है।
        </div>
      </section>
    </main>
  );
}
