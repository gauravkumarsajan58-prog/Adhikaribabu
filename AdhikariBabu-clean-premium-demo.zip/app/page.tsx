const categories = [
  { title: "Latest Jobs", icon: "💼", text: "सरकारी और प्राइवेट नौकरी अपडेट" },
  { title: "Results", icon: "📊", text: "Result, merit list और cutoff" },
  { title: "Admit Card", icon: "🎫", text: "Exam और recruitment admit card" },
  { title: "Study Material", icon: "📚", text: "Notes, PDFs और exam preparation" },
];

const updates = [
  { tag: "JOB", title: "Latest Government Job Updates", meta: "नई भर्ती • जल्द अपडेट होगा" },
  { tag: "RESULT", title: "Results & Merit Lists", meta: "Result • Cutoff • Selection list" },
  { tag: "EXAM", title: "Admit Card & Exam Notices", meta: "Exam date • City • Admit Card" },
];

export default function Home() {
  return (
    <main>
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between gap-4">
          <a href="/" className="text-xl font-extrabold tracking-tight text-blue-700">
            Adhikari<span className="text-slate-900">Babu</span>
          </a>

          <nav className="hidden items-center gap-5 text-sm font-semibold text-slate-600 md:flex">
            <a href="#jobs" className="hover:text-blue-700">Jobs</a>
            <a href="#results" className="hover:text-blue-700">Results</a>
            <a href="#admit-card" className="hover:text-blue-700">Admit Card</a>
            <a href="#study" className="hover:text-blue-700">Study Material</a>
            <a href="/premium" className="hover:text-amber-600">⭐ Premium</a>
          </nav>

          <a
            href="#updates"
            className="rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white shadow-sm hover:bg-blue-800"
          >
            Latest Updates
          </a>
        </div>
      </header>

      <section className="hero-grid border-b border-slate-200">
        <div className="container py-14 md:py-20">
          <div className="max-w-3xl">
            <div className="mb-4 inline-flex rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">
              🇮🇳 Jobs • Results • Exams • Study Material
            </div>
            <h1 className="text-4xl font-black leading-tight tracking-tight text-slate-950 md:text-6xl">
              सरकारी नौकरी और परीक्षा की
              <span className="text-blue-700"> सही जानकारी</span> एक जगह।
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600 md:text-lg">
              AdhikariBabu पर आपको jobs, results, admit cards, exam updates और
              study material आसान भाषा में मिलेगा।
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#categories" className="rounded-xl bg-blue-700 px-5 py-3 font-bold text-white hover:bg-blue-800">
                Categories देखें
              </a>
              <a href="#updates" className="rounded-xl border border-slate-300 bg-white px-5 py-3 font-bold text-slate-800 hover:bg-slate-50">
                Latest Updates
              </a>
              <a href="/premium" className="rounded-xl border border-amber-300 bg-amber-50 px-5 py-3 font-bold text-amber-800 hover:bg-amber-100">
                ⭐ Premium Demo
              </a>
            </div>
          </div>
        </div>
      </section>

      <section id="categories" className="container py-10">
        <div className="mb-6">
          <p className="text-sm font-bold text-blue-700">EXPLORE</p>
          <h2 className="mt-1 text-2xl font-black text-slate-950 md:text-3xl">आपको क्या चाहिए?</h2>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((item) => (
            <div key={item.title} className="card p-5 transition hover:-translate-y-1">
              <div className="text-3xl">{item.icon}</div>
              <h3 className="mt-4 text-lg font-extrabold">{item.title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{item.text}</p>
              <button className="mt-4 text-sm font-bold text-blue-700">Open →</button>
            </div>
          ))}
        </div>
      </section>

      <section id="updates" className="container py-4 pb-14">
        <div className="mb-6 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-bold text-emerald-700">LATEST</p>
            <h2 className="mt-1 text-2xl font-black text-slate-950 md:text-3xl">Latest Updates</h2>
          </div>
          <span className="hidden rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 sm:inline-block">
            Starter content
          </span>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          {updates.map((item) => (
            <article key={item.title} className="card p-5">
              <span className="inline-flex rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-black text-blue-700">
                {item.tag}
              </span>
              <h3 className="mt-4 text-lg font-extrabold leading-7">{item.title}</h3>
              <p className="mt-2 text-sm text-slate-600">{item.meta}</p>
              <button className="mt-5 text-sm font-bold text-blue-700">Read more →</button>
            </article>
          ))}
        </div>
      </section>

      <section id="study" className="border-y border-slate-200 bg-white">
        <div className="container grid gap-8 py-12 md:grid-cols-2 md:items-center">
          <div>
            <p className="text-sm font-bold text-purple-700">STUDY MATERIAL</p>
            <h2 className="mt-2 text-3xl font-black text-slate-950">
              Notes और PDFs के लिए अलग जगह
            </h2>
            <p className="mt-4 leading-7 text-slate-600">
              आगे चलकर यहाँ subject-wise notes, PDF library, bookmarks और
              search जैसी सुविधाएँ जोड़ी जाएँगी।
            </p>
          </div>
          <div className="card bg-slate-50 p-6">
            <div className="grid grid-cols-2 gap-3 text-sm font-bold">
              {["Maths", "Physics", "Chemistry", "Engineering", "General Knowledge", "Current Affairs"].map((x) => (
                <div key={x} className="rounded-xl border border-slate-200 bg-white p-4">{x}</div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="jobs" className="container py-12">
        <div className="card overflow-hidden bg-slate-950 p-7 text-white md:p-10">
          <p className="text-sm font-bold text-blue-300">ADHIKARIBABU</p>
          <h2 className="mt-2 text-3xl font-black md:text-4xl">एक भरोसेमंद exam-information platform</h2>
          <p className="mt-4 max-w-2xl leading-7 text-slate-300">
            यह अभी secure starter version है। Admin panel, database, posts,
            categories, PDF metadata और user accounts बाद के चरण में जोड़े जा सकते हैं।
          </p>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-white">
        <div className="container flex flex-col gap-2 py-7 text-sm text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} AdhikariBabu. All rights reserved.</p>
          <p>Built with Next.js + Tailwind CSS</p>
        </div>
      </footer>
    </main>
  );
}
